package stealth

import (
	"math/rand"
	"time"

	"github.com/go-rod/rod"
)

func HumanType(el *rod.Element, text string) error {
	for _, ch := range text {
		delay := time.Duration(80+rand.Intn(120)) * time.Millisecond
		time.Sleep(delay)

		if err := el.Input(string(ch)); err != nil {
			return err
		}

		if rand.Float32() < 0.1 {
			time.Sleep(time.Duration(300+rand.Intn(400)) * time.Millisecond)
		}
	}
	return nil
}
