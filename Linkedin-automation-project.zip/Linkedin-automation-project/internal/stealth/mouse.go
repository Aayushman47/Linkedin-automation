package stealth

import (
	"math"
	"math/rand"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/proto"
)

// MoveMouseHuman moves the mouse in a curved, human-like path
func MoveMouseHuman(page *rod.Page, targetX, targetY float64) {
	// Start from a random nearby position (Rod doesn't expose mouse position)
	startX := targetX + rand.Float64()*100 - 50
	startY := targetY + rand.Float64()*100 - 50

	// Control point for Bezier curve (adds natural curvature)
	ctrlX := (startX+targetX)/2 + rand.Float64()*120 - 60
	ctrlY := (startY+targetY)/2 + rand.Float64()*120 - 60

	steps := 25 + rand.Intn(20)

	for i := 0; i <= steps; i++ {
		t := float64(i) / float64(steps)

		// Quadratic Bezier curve
		x := math.Pow(1-t, 2)*startX +
			2*(1-t)*t*ctrlX +
			math.Pow(t, 2)*targetX

		y := math.Pow(1-t, 2)*startY +
			2*(1-t)*t*ctrlY +
			math.Pow(t, 2)*targetY

		page.Mouse.MoveTo(proto.Point{
			X: x,
			Y: y,
		})

		// Variable micro-delay
		time.Sleep(time.Duration(8+rand.Intn(15)) * time.Millisecond)
	}
}
