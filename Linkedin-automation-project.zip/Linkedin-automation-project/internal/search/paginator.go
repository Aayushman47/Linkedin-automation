package search

import "github.com/go-rod/rod/lib/proto"

// NextPage navigates to the next page if available
func (s *Searcher) NextPage() bool {
	nextBtn, err := s.page.Element(`button[aria-label="Next"]`)
	if err != nil {
		return false
	}

	if err := nextBtn.Click(proto.InputMouseButtonLeft, 1); err != nil {
		return false
	}

	return true
}
