package stealth

import (
	"math/rand"
	"time"
)

// Scheduler controls when automation is allowed to act
// to simulate realistic human working patterns.
type Scheduler struct {
	startHour int
	endHour   int

	breakEvery time.Duration
	breakFor   time.Duration

	lastBreak time.Time
}

// NewScheduler creates a scheduler with human-like work hours and breaks
func NewScheduler() *Scheduler {
	start := 9 + rand.Intn(2) // 9–10 AM
	end := 23 + rand.Intn(2)  // 5–6 PM

	return &Scheduler{
		startHour:  start,
		endHour:    end,
		breakEvery: time.Duration(45+rand.Intn(30)) * time.Minute, // 45–75 min
		breakFor:   time.Duration(3+rand.Intn(5)) * time.Minute,   // 3–8 min
		lastBreak:  time.Now(),
	}
}

// WithinBusinessHours checks if current time is within work hours
func (s *Scheduler) WithinBusinessHours() bool {
	now := time.Now()
	hour := now.Hour()

	return hour >= s.startHour && hour < s.endHour
}

// ShouldTakeBreak determines if a break is due
func (s *Scheduler) ShouldTakeBreak() bool {
	return time.Since(s.lastBreak) >= s.breakEvery
}

// TakeBreak simulates a human break
func (s *Scheduler) TakeBreak() {
	time.Sleep(s.breakFor)
	s.lastBreak = time.Now()
}

// CanActNow is the main gatekeeper for automation actions
func (s *Scheduler) CanActNow() bool {
	// Outside working hours → no actions
	if !s.WithinBusinessHours() {
		return false
	}

	// Take break if needed
	if s.ShouldTakeBreak() {
		s.TakeBreak()
	}

	return true
}
