package stealth

import (
	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/proto"
)

// Click performs a human-like click on an element
func (s *Controller) Click(page *rod.Page, el *rod.Element) error {
	// Ensure element is visible
	if err := el.ScrollIntoView(); err != nil {
		return err
	}

	// Natural hover before click
	if err := el.Hover(); err != nil {
		return err
	}

	// Human pause
	s.Timing.Sleep()

	// Click using Rod's stable API
	return el.Click(proto.InputMouseButtonLeft, 1)
}
