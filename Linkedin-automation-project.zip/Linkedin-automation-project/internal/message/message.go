package message

import (
	"log/slog"
	"os"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/proto"
)

type Messenger struct {
	log    *slog.Logger
	page   *rod.Page
	dryRun bool
}

func New(log *slog.Logger, page *rod.Page) *Messenger {
	return &Messenger{
		log:    log,
		page:   page,
		dryRun: os.Getenv("DRY_RUN") == "true",
	}
}

func (m *Messenger) Send(profileURL, text string) {
	if m.dryRun {
		m.log.Info("DRY-RUN: Follow-up message",
			"profile", profileURL,
			"messagePreview", text,
		)
		return
	}

	m.page.MustNavigate(profileURL)
	time.Sleep(2 * time.Second)

	msgBtn, err := m.page.ElementR("button", "Message")
	if err != nil {
		m.log.Warn("Message button not found", "profile", profileURL)
		return
	}

	msgBtn.Click(proto.InputMouseButtonLeft, 1)
	time.Sleep(1 * time.Second)

	m.page.MustElement("textarea").MustInput(text)
	m.page.MustElementR("button", "Send").MustClick()

	m.log.Info("LIVE: Message sent", "profile", profileURL)
}
