package persistence

import (
	"encoding/json"
	"os"
	"sync"
	"time"
)

// Store holds persistent automation state
type Store struct {
	mu sync.Mutex

	SeenProfiles map[string]time.Time `json:"seen_profiles"`
}

// NewStore initializes or loads persistent state
func NewStore(path string) (*Store, error) {
	store := &Store{
		SeenProfiles: make(map[string]time.Time),
	}

	// Load existing file if present
	data, err := os.ReadFile(path)
	if err == nil {
		_ = json.Unmarshal(data, store)
	}

	return store, nil
}

// HasSeen checks if a profile was already processed
func (s *Store) HasSeen(profile string) bool {
	s.mu.Lock()
	defer s.mu.Unlock()

	_, exists := s.SeenProfiles[profile]
	return exists
}

// MarkSeen records a processed profile
func (s *Store) MarkSeen(profile string) {
	s.mu.Lock()
	defer s.mu.Unlock()

	s.SeenProfiles[profile] = time.Now()
}

// Save writes state to disk
func (s *Store) Save(path string) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	data, err := json.MarshalIndent(s, "", "  ")
	if err != nil {
		return err
	}

	return os.WriteFile(path, data, 0644)
}
