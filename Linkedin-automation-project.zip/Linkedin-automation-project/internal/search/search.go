package search

import (
	"fmt"
	"net/url"

	"github.com/go-rod/rod"
)

type Searcher struct {
	page *rod.Page
	seen map[string]struct{}
}

func New(page *rod.Page) *Searcher {
	return &Searcher{
		page: page,
		seen: make(map[string]struct{}),
	}
}

func BuildSearchURL(keywords, location string, page int) string {
	params := url.Values{}
	params.Set("keywords", keywords)
	params.Set("location", location)
	params.Set("page", fmt.Sprintf("%d", page))

	return "https://www.linkedin.com/search/results/people/?" + params.Encode()
}
