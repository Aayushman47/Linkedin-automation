package main

import (
	"context"
	"os"
	"time"

	"linkedin-automation-poc/internal/auth"
	"linkedin-automation-poc/internal/browser"
	"linkedin-automation-poc/internal/config"
	"linkedin-automation-poc/internal/connect"
	"linkedin-automation-poc/internal/logger"
	"linkedin-automation-poc/internal/message"
	"linkedin-automation-poc/internal/persistence"
	"linkedin-automation-poc/internal/search"
	"linkedin-automation-poc/internal/stealth"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		panic(err)
	}

	logr := logger.New(cfg.LogLevel)
	logr.Info("LinkedIn Automation POC starting", "env", cfg.Environment)

	browserMgr, err := browser.New(browser.Config{
		Headless: false,
		Timeout:  2 * time.Minute,
	})
	if err != nil {
		logr.Error("browser launch failed", "err", err)
		return
	}
	defer browserMgr.Close()

	ctx := context.Background()
	page, err := browserMgr.NewPage(ctx)
	if err != nil {
		logr.Error("page creation failed", "err", err)
		return
	}

	page.MustSetViewport(1280, 800, 1, false)

	if os.Getenv("DEMO_AUTH") == "true" {
		authMgr := auth.New(page)
		if err := authMgr.LoginIfNeeded(); err != nil {
			logr.Warn("authentication blocked or failed", "reason", err.Error())
		} else {
			logr.Info("authentication successful")
		}
	}

	stealthCtrl := stealth.NewController()
	scheduler := stealth.NewScheduler()
	rateLimiter := stealth.NewRateLimiter(20, 5, 90*time.Second)

	searcher := search.New(page)

	store, err := persistence.NewStore("state.json")
	if err != nil {
		logr.Error("persistence init failed", "err", err)
		return
	}
	defer store.Save("state.json")

	connector := connect.New(logr, page)
	messenger := message.New(logr, page)

	logr.Info("Gate check",
		"scheduler", scheduler.CanActNow(),
		"rateLimiter", rateLimiter.CanAct(),
	)

	if rateLimiter.CanAct() {

		searchURL := search.BuildSearchURL(
			"full stack developer",
			"India",
			1,
		)

		stealthCtrl.Navigate(page, searchURL)

		profiles, err := searcher.ParseProfileLinks()
		if err != nil {
			logr.Warn("search parsing failed", "err", err)
		} else {

			logr.Info("Search result check", "profilesFound", len(profiles))

			if len(profiles) == 0 {
				profiles = []string{
					"https://www.linkedin.com/in/demo-profile",
				}
				logr.Info("No profiles found, using demo profile")
			}

			for _, profile := range profiles {
				if store.HasSeen(profile) {
					continue
				}

				store.MarkSeen(profile)

				connector.Send(
					profile,
					"Hi {{name}}, would love to connect!",
				)

				messenger.Send(
					profile,
					"Thanks for connecting, {{name}}!",
				)
			}
		}

		rateLimiter.RecordAction()
	} else {
		logr.Warn("execution blocked by rate limiter")
	}

	time.Sleep(2 * time.Minute)
}
