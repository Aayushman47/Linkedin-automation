package stealth

import (
	"sync"
	"time"
)

// RateLimiter controls how frequently actions can be performed
type RateLimiter struct {
	mu sync.Mutex

	dailyLimit  int
	hourlyLimit int
	cooldown    time.Duration

	dailyCount  int
	hourlyCount int

	lastAction time.Time
	lastReset  time.Time
}

// NewRateLimiter creates a human-safe rate limiter
func NewRateLimiter(daily, hourly int, cooldown time.Duration) *RateLimiter {
	now := time.Now()

	return &RateLimiter{
		dailyLimit:  daily,
		hourlyLimit: hourly,
		cooldown:    cooldown,
		lastReset:   now,
	}
}

// resetCounters resets daily/hourly counters when needed
func (r *RateLimiter) resetCountersIfNeeded(now time.Time) {
	// Reset daily at midnight
	if now.Day() != r.lastReset.Day() {
		r.dailyCount = 0
		r.hourlyCount = 0
		r.lastReset = now
		return
	}

	if now.Sub(r.lastReset) >= time.Hour {
		r.hourlyCount = 0
		r.lastReset = now
	}
}

func (r *RateLimiter) CanAct() bool {
	r.mu.Lock()
	defer r.mu.Unlock()

	now := time.Now()
	r.resetCountersIfNeeded(now)

	if r.dailyCount >= r.dailyLimit {
		return false
	}

	if r.hourlyCount >= r.hourlyLimit {
		return false
	}

	if !r.lastAction.IsZero() && now.Sub(r.lastAction) < r.cooldown {
		return false
	}

	return true
}

func (r *RateLimiter) RecordAction() {
	r.mu.Lock()
	defer r.mu.Unlock()

	r.dailyCount++
	r.hourlyCount++
	r.lastAction = time.Now()
}
