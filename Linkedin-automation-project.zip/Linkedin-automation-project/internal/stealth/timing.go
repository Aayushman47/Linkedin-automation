package stealth

import (
	"math/rand"
	"time"
)

type Timing struct {
	Min time.Duration
	Max time.Duration
}

func NewTiming(min, max time.Duration) Timing {
	return Timing{Min: min, Max: max}
}

// Sleep simulates human think time
func (t Timing) Sleep() {
	if t.Max <= t.Min {
		time.Sleep(t.Min)
		return
	}

	delta := rand.Int63n(int64(t.Max - t.Min))
	time.Sleep(t.Min + time.Duration(delta))
}
