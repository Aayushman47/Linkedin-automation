package stealth

import (
	"math/rand"
	"time"

	"github.com/go-rod/rod"
)

func RandomScroll(page *rod.Page) {
	steps := 3 + rand.Intn(5)

	for i := 0; i < steps; i++ {
		deltaY := 200 + rand.Float64()*400

		page.Mouse.Scroll(0, deltaY, 1)

		time.Sleep(time.Duration(300+rand.Intn(500)) * time.Millisecond)
	}

	if rand.Float32() < 0.3 {
		page.Mouse.Scroll(0, -150, 1)
	}
}
