package stealth

import (
	"math/rand"
	"time"

	"github.com/go-rod/rod"
)

func (s *Controller) Idle(page *rod.Page) {
	if rand.Float32() < 0.6 {
		RandomScroll(page)
	}

	// idle pause
	time.Sleep(time.Duration(2+rand.Intn(4)) * time.Second)
}
