package connect

import (
	"log/slog"
	"os"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/proto"
)

type Connector struct {
	log    *slog.Logger
	page   *rod.Page
	dryRun bool
}

func New(log *slog.Logger, page *rod.Page) *Connector {
	return &Connector{
		log:    log,
		page:   page,
		dryRun: os.Getenv("DRY_RUN") == "true",
	}
}

func (c *Connector) Send(profileURL, note string) {
	if c.dryRun {
		c.log.Info("DRY-RUN: Connection request",
			"profile", profileURL,
			"notePreview", note,
		)
		return
	}

	c.page.MustNavigate(profileURL)
	time.Sleep(2 * time.Second)

	btn, err := c.page.ElementR("button", "Connect")
	if err != nil {
		c.log.Warn("Connect button not found", "profile", profileURL)
		return
	}

	btn.Click(proto.InputMouseButtonLeft, 1)
	time.Sleep(1 * time.Second)

	if note != "" {
		if addNote, err := c.page.ElementR("button", "Add a note"); err == nil {
			addNote.Click(proto.InputMouseButtonLeft, 1)
			c.page.MustElement("textarea").MustInput(note)
			c.page.MustElementR("button", "Send").MustClick()
		}
	}

	c.log.Info("LIVE: Connection request sent", "profile", profileURL)
}
