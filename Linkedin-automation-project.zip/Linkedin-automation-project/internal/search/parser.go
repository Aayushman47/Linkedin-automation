package search

import (
	"strings"
)

// ParseProfileLinks extracts unique profile URLs from search results
func (s *Searcher) ParseProfileLinks() ([]string, error) {
	anchors, err := s.page.Elements(`a[href*="/in/"]`)
	if err != nil {
		return nil, err
	}

	results := make([]string, 0)

	for _, a := range anchors {
		href, err := a.Attribute("href")
		if err != nil || href == nil {
			continue
		}

		link := *href

		// Normalize
		if strings.Contains(link, "?") {
			link = strings.Split(link, "?")[0]
		}

		// Deduplicate
		if _, exists := s.seen[link]; exists {
			continue
		}

		s.seen[link] = struct{}{}
		results = append(results, link)
	}

	return results, nil
}
