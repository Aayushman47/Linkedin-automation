package browser

import (
	"context"
	"time"

	"github.com/go-rod/rod"
	"github.com/go-rod/rod/lib/launcher"
)

type Manager struct {
	browser *rod.Browser
}

type Config struct {
	Headless bool
	Timeout  time.Duration
}

func New(cfg Config) (*Manager, error) {
	u := launcher.New().
		Bin("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe").
		Leakless(false).
		Headless(false).
		NoSandbox(true).
		Devtools(true).
		MustLaunch()

	browser := rod.New().
		ControlURL(u).
		Timeout(cfg.Timeout)

	if err := browser.Connect(); err != nil {
		return nil, err
	}

	return &Manager{browser: browser}, nil
}

func (m *Manager) NewPage(ctx context.Context) (*rod.Page, error) {
	page := m.browser.MustPage("")
	page = page.Context(ctx)
	return page, nil
}

func (m *Manager) Close() error {
	return m.browser.Close()
}
