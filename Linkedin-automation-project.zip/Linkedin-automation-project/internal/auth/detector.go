package auth

import "github.com/go-rod/rod"

func IsLoggedIn(page *rod.Page) bool {
	// LinkedIn shows profile nav only when logged in
	_, err := page.Timeout(3 * 1e9).Element(`nav[aria-label="Primary"]`)
	return err == nil
}

func HasCheckpoint(page *rod.Page) bool {
	_, err := page.Element(`input[name=pin]`)
	if err == nil {
		return true
	}

	_, err = page.Element(`iframe[src*="captcha"]`)
	return err == nil
}
