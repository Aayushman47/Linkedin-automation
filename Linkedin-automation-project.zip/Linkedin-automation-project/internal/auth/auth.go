package auth

import (
	"errors"
	"os"

	"github.com/go-rod/rod"
)

/*
	DEMO-ONLY CREDENTIALS

These are intentionally isolated and must never be used in production.
Write your linked in credentials below to login to the program
*/
const demoEmail = "username"
const demoPassword = "password"

type Authenticator struct {
	page *rod.Page
}

func New(page *rod.Page) *Authenticator {
	return &Authenticator{page: page}
}

func (a *Authenticator) LoginIfNeeded() error {
	if IsLoggedIn(a.page) {
		return nil
	}

	email := os.Getenv("LINKEDIN_EMAIL")
	password := os.Getenv("LINKEDIN_PASSWORD")

	if email == "" || password == "" {
		email = demoEmail
		password = demoPassword
	}

	if email == "" || password == "" {
		return errors.New("no credentials available")
	}

	a.page.MustNavigate("https://www.linkedin.com/login")

	a.page.MustElement(`#username`).MustInput(email)
	a.page.MustElement(`#password`).MustInput(password)
	a.page.MustElement(`button[type=submit]`).MustClick()

	return nil
}
