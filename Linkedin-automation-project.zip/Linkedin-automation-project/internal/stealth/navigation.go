package stealth

import (
	"github.com/go-rod/rod"
)

func (s *Controller) Navigate(page *rod.Page, url string) {
	s.Timing.Sleep()
	page.MustNavigate(url)
	s.Timing.Sleep()
}
