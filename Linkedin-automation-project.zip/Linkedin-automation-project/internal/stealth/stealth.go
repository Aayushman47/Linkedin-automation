package stealth

import (
	"time"
)

type Controller struct {
	Timing Timing
}

func NewController() *Controller {
	return &Controller{
		Timing: NewTiming(800*time.Millisecond, 2500*time.Millisecond),
	}
}
